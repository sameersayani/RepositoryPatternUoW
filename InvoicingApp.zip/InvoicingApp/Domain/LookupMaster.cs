﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InvoicingApp.Model
{
    public class LookupMaster
    {
        public int QckLookupMasterID { get; set; }
        public DateTime? DateofLookup { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EntityName { get; set; }
        public string Npn { get; set; }
        public string CostCenterCode { get; set; }
        public string CostCenterDescription { get; set; }
        public decimal? Cost { get; set; }
    }
}
