﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InvoicingApp.Model
{
    public class Invoicing
    {
        public DateTime? TransactionEffectiveDate { get; set; }
        public DateTime? LastActionDate { get; set; }
        public int TransactionNumber { get; set; }
        public string State { get; set; }
        public string TransactionType { get; set; }
        public int? CustomerBatchId { get; set; }
        public int? CustomerTransactionId { get; set; }
        public int? TransactionId { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public string Company { get; set; }
        public string CostCenterCode { get; set; }
        public string CostCenterDescription { get; set; }
        public string Status { get; set; }
        public decimal? StateFee { get; set; }
        public decimal? TransactionFee { get; set; }
    }
}
