﻿using DataAccessLayer;
using InvoicingApp.Model;
using System;
using System.Collections.Generic;

namespace InvoicingApp
{
    class Program
    {
        private static IConnectionFactory connectionFactory;
        static void Main(string[] args)
        {
            Console.WriteLine(" Invoice Generator Started...");
            Console.Write("Please enter Start Date (mm/dd/yyyy) :");
            var startDate = Console.ReadLine();
            Console.Write("Please enter End Date (mm/dd/yyyy) :");
            var endDate = Console.ReadLine();
            var parserStart = DateTime.Parse(startDate);
            var parserEnd = DateTime.Parse(endDate);
            if(parserStart > parserEnd)
            {
                Console.WriteLine("ERROR :: Start Date cannot be greater than End Date");
                Console.WriteLine("Please enter Start Date (mm/dd/yyyy) :");
                startDate = Console.ReadLine();
                Console.WriteLine("Please enter End Date (mm/dd/yyyy) :");
                endDate = Console.ReadLine();
            }

            var lst = GetInvoicing(parserStart, parserEnd);
        }

        private static IList<Invoicing> GetInvoicing(DateTime from, DateTime to)
        {
            connectionFactory = ConnectionHelper.GetConnection();
            var conext = new DbContext(connectionFactory);
            var Invoice = new InvoicingRepository(conext);
            return Invoice.GetInvoicings(from, to);
        }
    }
}
